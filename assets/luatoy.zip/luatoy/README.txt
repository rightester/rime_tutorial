luatoy.exe    64 bit
rime.dll        64 bit 1.11.2
shared\       copy from rime tools with opencc folder
usr\             user data dir, specified in script.lua
log\             log dir, specified in script.lua
script.lua     script determines what you want the test to be

should be run in cmd, not powershell

luatoy.exe more info:

MD5: CB2372193BA4BFC7C04A738FF67B4612
SHA1: D5791E4B4BD96B937017058F3EF0F106DA997803
SHA256: 5DCC0ED26BC80482C4EC67E1053DED3E427970EEEABE0A290A0924D52172A97C
CRC32: 9240CEC4

https://www.virustotal.com/gui/file/5dcc0ed26bc80482c4ec67e1053ded3e427970eeeabe0a290a0924d52172a97c?nocache=1