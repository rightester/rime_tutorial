
print("hello world in lua!")

print("script works begin!")

--- test.setup_rime(app_name, shared_data_dir, user_data_dir, log_dir)
test.setup_rime("rime.luatoy", "./shared", "./usr", "./log")
--- test.init_rime()  no params, deploy
test.init_rime()
---test.add_session() no params
test.add_session()
--test.print_sessions() no params
test.print_sessions()

test.add_session()
test.print_sessions()

test.add_session()
--- test.select_schema(schema_id)
test.select_schema("luna_pinyin")
test.print_sessions()

-- test.kill_session(session_index) index >= 1
test.kill_session(1)
test.print_sessions()
--- test.switch_session(session_index) index >= 1
test.switch_session(2)
--- test.get_session(session_index) index >= 1
local id = test.get_session(10)
print(string.format("get_session id: 0x%x", id))
test.print_sessions()

test.select_schema("luna_pinyin")
test.print_sessions()
--- test.set_option(option_name, bool value)
test.set_option("zh_simp", true)
--test.set_option("zh_trad", false)

local cindex = test.get_index_of_current_session()
print("current session index: ", cindex)

local sid = test.get_session(3)
local sidx = test.get_index_of_session(sid)
print("specific session index: ", sidx)


--- test.simulate_keys(key_sequence)
test.simulate_keys("jx")
test.print_session()
test.select_candidate(2)
test.print_session()

--- test.destroy_sessions() no params
test.destroy_sessions()
--- test.finalize_rime() no params
test.finalize_rime()

print("script works end!")
